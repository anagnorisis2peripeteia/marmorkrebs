package pkg

func Div(a, b int) int { return a / b }
